package ie.controller.gestionebolle;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.DAO.BolleDao;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;



@WebServlet("/visualizzaBolla")
public class visualizzaBolla extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public visualizzaBolla() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection conn = null;
		
		Tecnico tecnico = (Tecnico)request.getSession().getAttribute("tecnico");
		if(tecnico.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		String id_bolla = request.getParameter("id");
		
		Bolla bolla = null;
		if(id_bolla!=null && !id_bolla.equals(""))
			try 
			{
					
				bolla = BolleDao.getBollaById(id_bolla);
			}
			 catch (Exception ex) 
			{
				ex.printStackTrace();
			}
	
		request.setAttribute("bolla", bolla);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/visualizzabolla.jsp");
		dispatcher.forward(request,response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}


}
