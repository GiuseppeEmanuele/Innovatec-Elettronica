package ie.controller.gestionebolle;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.manager.gestionebolle.ManagerBolle;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;

/**
 * Servlet implementation class areaClienti
 */
@WebServlet("/nuovaModificaBolla")
public class nuovaModificaBolla extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public nuovaModificaBolla() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ManagerBolle mb = new ManagerBolle();
		Tecnico tecnico = (Tecnico)request.getSession().getAttribute("tecnico");
		if(tecnico.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		try 
		{
            Bolla bolla = new Bolla();
			
			bolla.setId(Integer.parseInt(request.getParameter("form_id")));
			bolla.setId_cliente(request.getParameter("form_id_cliente")!=null ? Integer.parseInt(request.getParameter("form_id_cliente")) : 0);
			bolla.setId_tecnico(Integer.parseInt(tecnico.getId()));
	
			bolla.setTipo(request.getParameter("form_tipo"));
			bolla.setMarca(request.getParameter("form_marca"));
			bolla.setModello(request.getParameter("form_modello"));
			bolla.setAccessori_inclusi(request.getParameter("form_accessori_inclusi"));
			bolla.setData_in(request.getParameter("form_data_ingresso"));
			bolla.setData_out(request.getParameter("form_data_uscita"));
			bolla.setNote(request.getParameter("form_note"));
			bolla.setRelazione_tecnico(request.getParameter("form_relazione_tecnico"));
			bolla.setDifetto(request.getParameter("form_difetto"));
	
			
			bolla.setCosto(request.getParameter("form_costo").equals("") ? 0 : Integer.parseInt(request.getParameter("form_costo")));
			bolla.setGiorni_garanzia(request.getParameter("form_giorni_garanzia").equals("") ? 0 : Integer.parseInt(request.getParameter("form_giorni_garanzia")));
	
			
			bolla.setPreventivo(request.getParameter("form_preventivo")!=null);
			bolla.setRipari_in_garanzia(request.getParameter("form_riparazioni_garanzia")!=null);
			bolla.setAttesa_ricambi(request.getParameter("form_attesa_ricambi")!=null);
			bolla.setRiparato(request.getParameter("form_riparato")!=null);
			
			int ris_modcliente = mb.nuovaModificaBolla(bolla, tecnico);
			request.setAttribute("ris", ris_modcliente+"");
			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/visualizzaBolle");
			dispatcher.forward(request,response);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doGet(request, response);
	}
}
