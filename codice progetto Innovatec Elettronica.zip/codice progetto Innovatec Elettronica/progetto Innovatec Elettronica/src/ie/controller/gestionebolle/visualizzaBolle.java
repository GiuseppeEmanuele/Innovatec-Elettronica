package ie.controller.gestionebolle;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.DAO.BolleDao;
import ie.manager.gestionebolle.ManagerBolle;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;



@WebServlet("/visualizzaBolle")
public class visualizzaBolle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public visualizzaBolle() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ManagerBolle mb = new ManagerBolle();
		
		Tecnico tecnico = (Tecnico)request.getSession().getAttribute("tecnico");
		if(tecnico.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}


		
		try {
			
			String rim = request.getParameter("rim");
			
			mb.rimuoviBolla(rim);

			String f_rip = request.getParameter("f_rip")!=null ? request.getParameter("f_rip") : "";
			ArrayList<Bolla> bolle = BolleDao.getBolleByRiparatoIdTecnico(f_rip, tecnico.getId());
			request.setAttribute("bolle", bolle);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/visualizzabolle.jsp");
			dispatcher.forward(request,response);
			
		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}

	

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
}
