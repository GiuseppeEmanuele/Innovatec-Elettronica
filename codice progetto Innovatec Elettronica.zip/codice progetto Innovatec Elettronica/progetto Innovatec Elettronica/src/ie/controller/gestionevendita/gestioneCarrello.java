package ie.controller.gestionevendita;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.model.gestioneprodotti.Prodotto;
import ie.model.gestionevendita.Carrello;

/**
 * Servlet implementation class areaClienti
 */
@WebServlet("/gestioneCarrello")
public class gestioneCarrello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public gestioneCarrello() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection conn = null;
		Carrello carrello = (Carrello)request.getSession().getAttribute("carrello");
		PrintWriter out = response.getWriter();

		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/progettoPW", "root", "");
			
			
			
			
			String add = request.getParameter("add");
			String rem = request.getParameter("rem");
			
			int ris = 0;
			
			if(add!=null)
			{
				int id_prodotto = Integer.parseInt(add);
				if(carrello.esisteProdotto(id_prodotto))
					ris=-1;
				else
				{
					Prodotto p = getProdotto(id_prodotto, conn);
					carrello.addProdotto(p);
					ris=1;
				}
			}
			
			if(rem!=null)
			{
				int id_prodotto = Integer.parseInt(rem);
				Prodotto p = carrello.remProdotto(id_prodotto);
				if(p==null)
					ris=-1;
				else
				{
					ris=1;
					//request.setAttribute("prodotto", p);
				}
				
			}
			
			out.println(String.valueOf(ris));
			//RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/carrello.jsp");
			//dispatcher.forward(request,response);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		finally
		{
		    try
		    {
		        conn.close();
		    }
		    catch (SQLException e)
		    {
		        e.printStackTrace();
		    }
		}

	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

	
	private Prodotto getProdotto(int id_prodotto, Connection conn)
	{
		String sqlStr = "SELECT * FROM prodotti WHERE id=?";
		

		try
		{
			PreparedStatement ps = conn.prepareStatement(sqlStr);
			ps.setInt(1, id_prodotto);
	
			ResultSet rset = ps.executeQuery();
			
			
			if(rset.next())
			{
				Prodotto prodotto = new Prodotto();
				
				prodotto.setId(rset.getInt("id"));
				prodotto.setDescrizione(rset.getString("descrizione"));
				prodotto.setNome_img(rset.getString("nome_img"));
				prodotto.setCosto(rset.getDouble("costo"));
				
				return prodotto;
			}
		}
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		finally
		{
		    try
		    {
		        conn.close();
		    }
		    catch (SQLException e)
		    {
		        e.printStackTrace();
		    }
		}

		return null;
	}
	
	
	
}
