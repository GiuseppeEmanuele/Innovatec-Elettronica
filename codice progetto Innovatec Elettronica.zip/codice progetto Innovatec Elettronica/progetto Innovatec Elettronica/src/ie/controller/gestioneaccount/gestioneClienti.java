package ie.controller.gestioneaccount;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CosNaming.IstringHelper;

import ie.DAO.ClientiDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Gestore;
import ie.model.gestioneaccount.Tecnico;

/**
 * Servlet implementation class areaClienti
 */
@WebServlet("/gestioneClienti")
public class gestioneClienti extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public gestioneClienti() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ManagerAccount ma = new  ManagerAccount();
		
		Tecnico tecnico = (Tecnico)request.getSession().getAttribute("tecnico");
		
		if(tecnico.getId().equals(""))
			tecnico = (Tecnico)request.getSession().getAttribute("gestore");
		
		if(tecnico.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		try {
			String form_id = request.getParameter("form_id");
			String rem_id = request.getParameter("rim");
			String id_cliente = request.getParameter("id_cliente");
			
			if(rem_id!=null)
			{
				int ris_remcliente = ma.rimuoviCliente(rem_id);
				request.setAttribute("ris", ris_remcliente+"");
			}
			
			
			if(form_id!=null && form_id.equals("")) //nuovo cliente
			{
				Cliente cliente = new Cliente();
				cliente.setCodfis(request.getParameter("form_codicefiscale"));
				cliente.setNome(request.getParameter("form_nome"));
				cliente.setCognome(request.getParameter("form_cognome"));
				cliente.setIndirizzo(request.getParameter("form_indirizzo"));
				cliente.setEmail(request.getParameter("form_email"));
				cliente.setTelefono(request.getParameter("form_telefono"));
				cliente.setNote(request.getParameter("form_note"));
				
				int ris_nuovocliente = ma.aggiungiCliente(cliente, tecnico);
				request.setAttribute("ris", ris_nuovocliente+"");
			}
			else
			if(form_id!=null) // modifica cliente
			{
				
				Cliente cliente = new Cliente();
				cliente.setCodfis(request.getParameter("form_codicefiscale"));
				cliente.setNome(request.getParameter("form_nome"));
				cliente.setCognome(request.getParameter("form_cognome"));
				cliente.setIndirizzo(request.getParameter("form_indirizzo"));
				cliente.setEmail(request.getParameter("form_email"));
				cliente.setTelefono(request.getParameter("form_telefono"));
				cliente.setNote(request.getParameter("form_note"));
				
				int ris_modcliente = ma.modificaCliente(cliente);
				request.setAttribute("ris", ris_modcliente+"");
				id_cliente=form_id;
			}
			
			ArrayList<Cliente> clienti = null;
			
			if(tecnico.getClass() == Tecnico.class)
				clienti=ClientiDao.getClientiByIdTecnico(tecnico.getId());
			else
			if(tecnico.getClass() == Gestore.class)
				clienti=ClientiDao.getAllClienti();
			
			
			if(id_cliente!=null)
			{
				request.setAttribute("mod_cliente", ClientiDao.getClienteById(id_cliente));
			}

			
			
			request.setAttribute("clienti", clienti);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/gestioneclienti.jsp");
			dispatcher.forward(request,response);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	
	


}
