package ie.controller.gestioneaccount;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.DAO.TecniciDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.model.gestioneaccount.Gestore;
import ie.model.gestioneaccount.Tecnico;


/**
 * Servlet implementation class areaClienti
 */
@WebServlet("/gestioneTecnici")
public class gestioneTecnici extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public gestioneTecnici() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ManagerAccount ma = new ManagerAccount();
		Gestore gestore = (Gestore)request.getSession().getAttribute("gestore");
		
		if(gestore.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		
		try {

			String form_id = request.getParameter("form_id");
			String id_tecnico = request.getParameter("id_tecnico");
			String rem_id = request.getParameter("rim");
			
			if(rem_id!=null)
			{
				int ris_remcliente = ma.rimuoviTecnico(rem_id);
				request.setAttribute("ris", ris_remcliente+"");
			}

			
			
			if(form_id!=null && form_id.equals("")) //nuovo tecnico
			{
				
				Tecnico tecnico = new Tecnico();
				
				tecnico.setPwd(request.getParameter("form_password"));
				tecnico.setNome(request.getParameter("form_nome"));
				tecnico.setCognome(request.getParameter("form_cognome"));
				tecnico.setIndirizzo(request.getParameter("form_indirizzo"));
				tecnico.setEmail(request.getParameter("form_email"));
				tecnico.setTelefono(request.getParameter("form_telefono"));
				tecnico.setNote(request.getParameter("form_note"));
				tecnico.setType(request.getParameter("form_type"));
				tecnico.setCodfis(request.getParameter("form_codicefiscale"));
				
				int ris_nuovotecnico = ma.aggiungiTecnico(tecnico);
				request.setAttribute("ris_nuovo", ris_nuovotecnico+"");
				
			}
			else
			if(form_id!=null) // modifica tecnico
			{
				Tecnico tecnico = new Tecnico();
				tecnico.setPwd(request.getParameter("form_pwd"));
				tecnico.setNome(request.getParameter("form_nome"));
				tecnico.setCognome(request.getParameter("form_cognome"));
				tecnico.setIndirizzo(request.getParameter("form_indirizzo"));
				tecnico.setEmail(request.getParameter("form_email"));
				tecnico.setTelefono(request.getParameter("form_telefono"));
				tecnico.setNote(request.getParameter("form_note"));
				tecnico.setType(request.getParameter("form_type"));
				tecnico.setCodfis(request.getParameter("form_codicefiscale"));
				
				int ris_modtecnico = ma.modificaTecnico(tecnico);
				request.setAttribute("ris_modifica", ris_modtecnico+"");
				id_tecnico=form_id;
			}
			
			ArrayList<Tecnico> tecnici = TecniciDao.getAllTecnici();

			if(id_tecnico!=null)
				request.setAttribute("mod_tecnico", TecniciDao.getTecnicoById(id_tecnico));

			request.setAttribute("tecnici", tecnici);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/gestionetecnici.jsp");
			dispatcher.forward(request,response);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
}
