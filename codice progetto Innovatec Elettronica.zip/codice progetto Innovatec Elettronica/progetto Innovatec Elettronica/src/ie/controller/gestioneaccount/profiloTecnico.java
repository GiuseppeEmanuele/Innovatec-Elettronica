package ie.controller.gestioneaccount;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.DAO.TecniciDao;
import ie.manager.gestioneaccount.ManagerProfilo;
import ie.model.gestioneaccount.Gestore;
import ie.model.gestioneaccount.Tecnico;


/**
 * Servlet implementation class areaClienti
 */
@WebServlet("/profiloTecnico")
public class profiloTecnico extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public profiloTecnico() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ManagerProfilo mp = new ManagerProfilo();
		Tecnico sesTecnico = (Tecnico)request.getSession().getAttribute("tecnico");
		
		if(sesTecnico.getId().equals(""))
			sesTecnico = (Tecnico)request.getSession().getAttribute("gestore");

		if(sesTecnico.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		
		try {

			String form_id = request.getParameter("form_id");
			String rem_id = request.getParameter("rim");
			
			if(rem_id!=null)
			{
				
				TecniciDao td = new TecniciDao();
				int ris_remcliente = td.rimuoviTecnicoById(rem_id);;
				request.setAttribute("ris", ris_remcliente+"");
			}

			
			
			if(form_id!=null) // modifica tecnico
			{
				Tecnico tecnico = new Tecnico();
				
				tecnico.setId(request.getParameter("form_id"));
				tecnico.setPwd(request.getParameter("form_password"));
				tecnico.setNome(request.getParameter("form_nome"));
				tecnico.setCognome(request.getParameter("form_cognome"));
				tecnico.setIndirizzo(request.getParameter("form_indirizzo"));
				tecnico.setEmail(request.getParameter("form_email"));
				tecnico.setTelefono(request.getParameter("form_telefono"));
				tecnico.setNote(request.getParameter("form_note"));
				tecnico.setType(request.getParameter("form_type"));
				tecnico.setCodfis(request.getParameter("form_codicefiscale"));
				
				int ris_modtecnico = mp.modificaProfiloTecnico(tecnico);
				request.setAttribute("ris_modifica", ris_modtecnico+"");
			}
			
			
			request.setAttribute("mod_tecnico", TecniciDao.getTecnicoById(sesTecnico.getId()));
			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/profilotecnico.jsp");
			dispatcher.forward(request,response);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	
	

}
