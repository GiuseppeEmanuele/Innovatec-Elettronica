package ie.controller.gestioneaccount;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ie.DAO.ClientiDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;

/**
 * Servlet implementation class areaClienti
 */
@WebServlet("/visualizzaClienti")
public class visualizzaClienti extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public visualizzaClienti() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection conn = null;

		Tecnico tecnico = (Tecnico)request.getSession().getAttribute("tecnico");
		if(tecnico.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		try 
		{
			ArrayList<Cliente> clienti = ClientiDao.getClientiByIdTecnico(tecnico.getId());
			request.setAttribute("clienti", clienti);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/visualizzaclienti.jsp");
			dispatcher.forward(request,response);
		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		finally
		{
		    try
		    {
		        conn.close();
		    }
		    catch (SQLException e)
		    {
		        e.printStackTrace();
		    }
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	
}
