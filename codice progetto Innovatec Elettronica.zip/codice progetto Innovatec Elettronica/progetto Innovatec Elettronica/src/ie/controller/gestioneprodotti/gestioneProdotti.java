package ie.controller.gestioneprodotti;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.html.HTMLDocument.Iterator;

import ie.DAO.ProdottiDao;
import ie.manager.gestioneprodotti.ManagerProdotti;
import ie.model.gestioneaccount.Gestore;
import ie.model.gestioneprodotti.Prodotto;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;




/**
 * Servlet implementation class gestioneProdotti
 */
@WebServlet("/gestioneProdotti")
public class gestioneProdotti extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public gestioneProdotti() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ManagerProdotti mp = new ManagerProdotti();
		Gestore gestore = (Gestore)request.getSession().getAttribute("gestore");
		
		if(gestore.getId().equals(""))
		{
			response.sendRedirect("login.jsp");
			return;
		}
		
		mp.nuovoModificaProdotto(request);
		try {
			String form_id = request.getParameter("form_id");
			String rem_id = request.getParameter("rim");
			String id_prodotto = request.getParameter("id_prodotto");
			
			
			if(rem_id!=null)
			{
				int ris_remprodotto = mp.rimuoviProdotto(rem_id);
				request.setAttribute("ris", ris_remprodotto+"");
			}
			
			
			if(form_id!=null && form_id.equals("0")) //nuovo prodotto
			{
				Prodotto prodotto = new Prodotto();
				prodotto.setDescrizione(request.getParameter("form_descrizione"));
				prodotto.setCosto(Double.parseDouble(request.getParameter("form_costo")));
				prodotto.setNome_img(request.getParameter("form_nomeimg"));
				
				int ris_nuovoprodotto = mp.nuovoProdotto(prodotto);
				request.setAttribute("ris", ris_nuovoprodotto+"");
			}
			else
			if(form_id!=null) // modifica prodotto
			{
				//int ris_modprodotto = mp.modificaProdotto(request);
				//request.setAttribute("ris", ris_modprodotto+"");
			}
			
			ArrayList<Prodotto> prodotto = ProdottiDao.getAllProdotti();
			
			if(id_prodotto!=null)
				request.setAttribute("mod_prodotto", ProdottiDao.getProdottoById(id_prodotto));
			else
			if(form_id!=null && !form_id.equals("0"))
				request.setAttribute("mod_prodotto", ProdottiDao.getProdottoById(form_id));

			
			
			request.setAttribute("prodotti", prodotto);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/gestioneprodotti.jsp");
			dispatcher.forward(request,response);

		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}		
		
//		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/gestioneprodotti.jsp");
//		dispatcher.forward(request,response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
