package ie;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ie.model.gestioneprodotti.Prodotto;


public class VisualizzaProdottiDestra
{
	private ArrayList<Prodotto> prodotti;
	

	private VisualizzaProdottiDestra()
	{
	}
	
	
	public VisualizzaProdottiDestra(int limit)
	{
		Connection conn = null;
		prodotti = new ArrayList<Prodotto>();
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/progettoPW", "root", "");
			
			String sqlStr = "SELECT * FROM prodotti ORDER BY RAND() LIMIT ?";
			
			
			PreparedStatement ps = conn.prepareStatement(sqlStr);
			ps.setInt(1, limit);
			ResultSet rset = ps.executeQuery();
			
			while(rset.next())
			{
				Prodotto prodotto = new Prodotto();
				
				prodotto.setId(rset.getInt("id"));
				prodotto.setDescrizione(rset.getString("descrizione"));
				prodotto.setNome_img(rset.getString("nome_img"));
				prodotto.setCosto(rset.getDouble("costo"));
				
				prodotti.add(prodotto);
			}
		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		finally
		{
		    try
		    {
		        conn.close();
		    }
		    catch (SQLException e)
		    {
		        e.printStackTrace();
		    }
		}
	}

	public ArrayList<Prodotto> getProdotti()
	{
		return prodotti;
	}
	
}

