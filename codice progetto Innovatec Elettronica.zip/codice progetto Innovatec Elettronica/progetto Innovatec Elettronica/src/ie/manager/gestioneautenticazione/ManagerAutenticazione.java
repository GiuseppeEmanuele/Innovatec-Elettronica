package ie.manager.gestioneautenticazione;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import ie.DAO.ClientiDao;
import ie.DAO.TecniciDao;
import ie.model.gestioneaccount.Gestore;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestioneaccount.UtenteRegistrato;

public class ManagerAutenticazione 
{
	
	public UtenteRegistrato loginCheck(String codFis, String pwd)
	{
		try 
		{
			Tecnico t = TecniciDao.cercaByCodFisPwd(codFis, pwd);

			if(t!=null)
			{
				if(t.getType().equals("admin"))
				{
					Gestore g = new Gestore();
					g.setId(t.getId());
					g.setPwd(t.getPwd());
					g.setNome(t.getNome());
					g.setCognome(t.getCognome());
					g.setCodfis(t.getCodfis());
					g.setIndirizzo(t.getIndirizzo());
					g.setEmail(t.getEmail());
					g.setTelefono(t.getTelefono());
					g.setNote(t.getNote());
					return g;
				}
				else
					return t;
			}
			else
			{
				 
				
				return ClientiDao.cercaByCodFisPwd(codFis, pwd);
				
			}
		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		
		return null;
	}
	
	public void logout(HttpSession session)
	{
		session.setAttribute("tecnico", null);
		session.setAttribute("cliente", null);
		session.setAttribute("gestore", null);
	}


}
