package ie.manager.gestioneaccount;

import javax.servlet.http.HttpServletRequest;

import ie.DAO.ClientiDao;
import ie.DAO.TecniciDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;

public class ManagerProfilo 
{
	
	public int modificaProfiloCliente(Cliente cliente)
	{
		

		
		int ris_modcliente=0;
		try {
			ris_modcliente = ClientiDao.modificaClienteByCodfis(cliente);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ris_modcliente;

	}

	public int modificaProfiloTecnico(Tecnico tecnico)
	{
		
		
		int ris_modtecnico=0;
		try 
		{
			ris_modtecnico = TecniciDao.modificaTecnico(tecnico);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}

		
		return ris_modtecnico;
	}
}
