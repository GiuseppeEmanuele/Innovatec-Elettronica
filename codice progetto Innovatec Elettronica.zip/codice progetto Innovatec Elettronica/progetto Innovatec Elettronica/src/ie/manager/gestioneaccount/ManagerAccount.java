package ie.manager.gestioneaccount;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import ie.DAO.ClientiDao;
import ie.DAO.TecniciDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.test.dao.ClientiDaoStub;

public class ManagerAccount 
{
	
	public int aggiungiCliente(Cliente cliente, Tecnico tecnico)
	{
		
		
		int ris_nuovocliente=0;
		try {
			//ClientiDaoStub cd = new ClientiDaoStub();
			
			ClientiDao cd = new ClientiDao();			
			ris_nuovocliente = cd.addCliente(cliente, tecnico);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ris_nuovocliente;
	}
	

	
	public int modificaCliente(Cliente cliente)
	{
		

		int ris_modcliente=0;
		try {
			ris_modcliente = ClientiDao.modificaClienteByCodfis(cliente);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ris_modcliente;
		
	}
	
	public int rimuoviCliente(String rem_id)
	{
		int ret = 0;
		try {
          //ClientiDaoStub cd = new ClientiDaoStub();
			
			ClientiDao cd = new ClientiDao();	
			ret = cd.rimuoviClienteById(rem_id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	
	
	public int aggiungiTecnico(Tecnico tecnico)
	{
		
		
		int ris_nuovotecnico=0;
		try {
        //TecniciDaoStub td = new TecniciDaoStub();
			
			TecniciDao td = new TecniciDao();
			
			ris_nuovotecnico = td.addTecnico(tecnico);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ris_nuovotecnico;

	}
	
	public int modificaTecnico(Tecnico tecnico)
	{
	

		
		int ris_modtecnico=0;
		try {
			ris_modtecnico = TecniciDao.modificaTecnico(tecnico);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ris_modtecnico;

	}
	
	public int rimuoviTecnico(String rem_id)
	{
		int ret = 0;
		try {
	        //TecniciDaoStub td = new TecniciDaoStub();
			
				TecniciDao td = new TecniciDao();
			
			ret = td.rimuoviTecnicoById(rem_id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	
	public int registrazioneCliente(HttpServletRequest request)
	{
		Cliente cliente = new Cliente();
		cliente.setCodfis(request.getParameter("form_codicefiscale"));
		cliente.setNome(request.getParameter("form_nome"));
		cliente.setCognome(request.getParameter("form_cognome"));
		cliente.setIndirizzo(request.getParameter("form_indirizzo"));
		cliente.setEmail(request.getParameter("form_email"));
		cliente.setTelefono(request.getParameter("form_telefono"));
		cliente.setPwd(request.getParameter("form_pwd"));
		
		int ris =0;
		try 
		{
			ris = ClientiDao.addCliente(cliente);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return ris;
	}

	
	
}
