package ie.manager.gestionebolle;

import javax.servlet.http.HttpServletRequest;

import ie.DAO.BolleDao;
import ie.DAO.TecniciDao;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;

public class ManagerBolle 
{
	public int rimuoviBolla(String id)
	{
		if(id!=null)
			try {
		        //BolleDaoStub bd = new BolleDaoStub();
				
				BolleDao bd = new BolleDao();
				return bd.rimuoviBollaById(id);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return 0;
	}

	
	
	public int nuovaModificaBolla(Bolla bolla, Tecnico tecnico)
	{
		try
		{
			
			
			if(bolla.getId()==0) //nuova bolla
			{
		        //BolleDaoStub bd = new BolleDaoStub();
				
				BolleDao bd = new BolleDao();
				return bd.addBolla(bolla);
				
			}
			else
			if(bolla.getId()!=0) //modifica bolla
			{
				return BolleDao.modificaBolla(bolla);
				
			}
		} catch (Exception ex) 
		{
			ex.printStackTrace();
			return -1;
		}
		
		return 0;
	}
	
}
