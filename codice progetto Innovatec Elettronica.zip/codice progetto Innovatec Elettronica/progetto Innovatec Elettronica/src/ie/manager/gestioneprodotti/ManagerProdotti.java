package ie.manager.gestioneprodotti;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import ie.DAO.ProdottiDao;
import ie.DAO.TecniciDao;
import ie.model.gestioneprodotti.Prodotto;

public class ManagerProdotti 
{
	public int nuovoProdotto(Prodotto prodotto)
	{
		
		
		int ris_nuovoprodotto=0;
		try {
	        //ProdottiDaoStub pd = new ProdottiDaoStub();
			
				ProdottiDao pd = new ProdottiDao();
			
			ris_nuovoprodotto = pd.addProdotto(prodotto);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ris_nuovoprodotto;
	}
	
	public int nuovoModificaProdotto(HttpServletRequest request)
	{
		if(ServletFileUpload.isMultipartContent(request))
		{
            try 
            {
            	DiskFileItemFactory factory = new DiskFileItemFactory();
            	ServletFileUpload upload = new ServletFileUpload(factory);
            	List<FileItem> files = new ServletFileUpload(factory).parseRequest(request);
            	
        		Prodotto prodotto = new Prodotto();
        		FileItem itemFile = null;
            	
            	for (FileItem item : files) 
            	{
            	    if (item.isFormField())
            	    {
            	        String fieldname = item.getFieldName();
            	        String fieldvalue = item.getString();

            	        if(fieldname.equals("form_id")) prodotto.setId(Integer.parseInt(fieldvalue));
            	        else
            	        if(fieldname.equals("form_descrizione")) prodotto.setDescrizione(fieldvalue);
            	        else
            	        if(fieldname.equals("form_costo")) prodotto.setCosto(Double.parseDouble(fieldvalue));
            	        
            	        System.out.println(fieldname+" : "+fieldvalue);
            	    } 
            	    else 
            	    {
            	    	itemFile = item;
            	    }
            	}
            	
    			if(prodotto.getId()==0) //nuovo prodotto
    			{
    		        //ProdottiDaoStub pd = new ProdottiDaoStub();
    				
    				ProdottiDao pd = new ProdottiDao();
    				
    				int idProdotto = pd.addProdotto(prodotto);
    				prodotto.setId(idProdotto);
    				request.setAttribute("ris", idProdotto+"");
    			}
    			else
    			if(prodotto.getId()!=0) // modifica prodotto
    			{
    				int ris_modprodotto = ProdottiDao.modificaProdottoById(prodotto);
    				request.setAttribute("ris", ris_modprodotto+"");
    				return ris_modprodotto;
    			}
            	
            	if(itemFile!=null && !itemFile.getName().equals(""))
            	{
	    	    	InputStream is = itemFile.getInputStream();
	    	        System.out.println(itemFile.getFieldName());
	    	        
	    	        File f = new File(request.getServletContext().getRealPath("")+"img/prodotti/"+prodotto.getId()+".jpg");
	    	        if(f.exists()) 
	    	        {
	    	        	f.delete();
	    	        	f.createNewFile();
	    	        }
	    	        System.out.println(f.getAbsolutePath());
	    	        
	    	        FileOutputStream fos = new FileOutputStream(f);
	    	        int x = is.read();
	
	    	        while (x >= 0) 
	    	        {
	    	            fos.write((byte) x);
	    	            x = is.read();
	    	        }
	    	        fos.close();
            	}
            	
            }
            catch (Exception ex) 
            {
            	ex.printStackTrace();
            }         
        }
		
		return 0;
		
	}
	

	
	public int rimuoviProdotto(String rim)
	{
		
		int ris=0;
		try 
		{
	        //ProdottiDaoStub pd = new ProdottiDaoStub();
			
				ProdottiDao pd = new ProdottiDao();
			
			ris= pd.rimuoviProdottoById(rim);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ris;
	}

}
