package ie.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;

public class BolleDao 
{
	
	
	public static ArrayList<Bolla> getBolleByRiparatoIdTecnico(String isRiparato, String idTecnico) throws Exception
	{
		System.out.println("getAllBolleByIdTecnico()");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
		
		
		String where = "";
		if(isRiparato.equals("1"))
			where+=" && riparato = true";
		else
		if(isRiparato.equals("2"))
			where+=" && riparato = false";


		String sqlStr = "SELECT * FROM bolle WHERE id_tecnico=? "+where+" ORDER BY id DESC";
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		ps.setInt(1, Integer.parseInt(idTecnico));
		ResultSet rset = ps.executeQuery();
		
		ArrayList<Bolla> bolle = new ArrayList<Bolla>();
		
		while(rset.next())
		{
			Bolla bolla = new Bolla();
			
			bolla.setId(rset.getInt("id"));
			bolla.setId_cliente(rset.getInt("id_cliente"));
			bolla.setId_tecnico(rset.getInt("id_tecnico"));
			bolla.setTipo(rset.getString("tipo"));
			bolla.setMarca(rset.getString("marca"));
			bolla.setModello(rset.getString("modello"));
			bolla.setAccessori_inclusi(rset.getString("accesincl"));
			bolla.setData_in(rset.getString("datain"));
			bolla.setData_out(rset.getString("dataout"));
			bolla.setNote(rset.getString("note"));
			bolla.setCosto(rset.getInt("costo"));
			bolla.setRelazione_tecnico(rset.getString("reltec"));	
			bolla.setPreventivo(rset.getBoolean("preventivo"));
			bolla.setGiorni_garanzia(rset.getInt("giornigaran"));
			bolla.setRipari_in_garanzia(rset.getBoolean("riparingaran"));
			bolla.setAccessori_inclusi(rset.getString("attesaricambi"));
			bolla.setRiparato(rset.getBoolean("riparato"));
			bolla.setDifetto(rset.getString("difetto"));
			
			bolle.add(bolla);
		}
		
		conn.close();
		return bolle;
		
	}

	public static Bolla getBollaById(String id) throws Exception
	{
		System.out.println("getBollaById(String id)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
		
		
		String sqlStr = "SELECT * FROM bolle WHERE id=?";
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		ps.setInt(1, Integer.parseInt(id));
		
		ResultSet rset = ps.executeQuery();
		Bolla bolla = null;
		
		
		if(rset.next())
		{
			bolla = new Bolla();
			bolla.setId(rset.getInt("id"));
			bolla.setId_cliente(rset.getInt("id_cliente"));
			bolla.setId_tecnico(rset.getInt("id_tecnico"));
			bolla.setTipo(rset.getString("tipo"));
			bolla.setMarca(rset.getString("marca"));
			bolla.setModello(rset.getString("modello"));
			bolla.setAccessori_inclusi(rset.getString("accesincl"));
			bolla.setData_in(rset.getString("datain"));
			bolla.setData_out(rset.getString("dataout"));
			bolla.setNote(rset.getString("note"));
			bolla.setCosto(rset.getInt("costo"));
			bolla.setRelazione_tecnico(rset.getString("reltec"));	
			bolla.setPreventivo(rset.getBoolean("preventivo"));
			bolla.setGiorni_garanzia(rset.getInt("giornigaran"));
			bolla.setRipari_in_garanzia(rset.getBoolean("riparingaran"));
			bolla.setAttesa_ricambi(rset.getBoolean("attesaricambi"));
			bolla.setRiparato(rset.getBoolean("riparato"));
			bolla.setDifetto(rset.getString("difetto"));
			
		}
		
		conn.close();
		return bolla;
		
	}

	public static Bolla cercaBollaByIdCodfis(String idBolla, String codfis) throws Exception
	{
		System.out.println("getBollaById(String id)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
		
		
		String sqlStr =
				" SELECT b.*"+	
				" FROM bolle b"+
				" JOIN clienti c"+
				" ON(b.id_cliente=c.id)"+
				" WHERE b.id=? AND c.codfis=?";
				
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		
		ps.setString(1, idBolla);
		ps.setString(2, codfis);
		
		ResultSet rset = ps.executeQuery();
		
		Bolla bolla = null;
		
		if(rset.next())
		{
			bolla = new Bolla();
			
			bolla.setId(rset.getInt("id"));
			bolla.setId_cliente(rset.getInt("id_cliente"));
			bolla.setId_tecnico(rset.getInt("id_tecnico"));
			bolla.setTipo(rset.getString("tipo"));
			bolla.setMarca(rset.getString("marca"));
			bolla.setModello(rset.getString("modello"));
			bolla.setAccessori_inclusi(rset.getString("accesincl"));
			bolla.setData_in(rset.getString("datain"));
			bolla.setData_out(rset.getString("dataout"));
			bolla.setNote(rset.getString("note"));
			bolla.setCosto(rset.getInt("costo"));
			bolla.setRelazione_tecnico(rset.getString("reltec"));	
			bolla.setPreventivo(rset.getBoolean("preventivo"));
			bolla.setGiorni_garanzia(rset.getInt("giornigaran"));
			bolla.setRipari_in_garanzia(rset.getBoolean("riparingaran"));
			bolla.setAccessori_inclusi(rset.getString("attesaricambi"));
			bolla.setRiparato(rset.getBoolean("riparato"));
			bolla.setDifetto(rset.getString("difetto"));
		}
		
		conn.close();
		return bolla;
		
	}

	public  int rimuoviBollaById(String id) throws Exception 
	{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
			String sql = "DELETE FROM bolle WHERE id=?;";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			
			System.out.println(ps.toString());
			
			int rownum = ps.executeUpdate();
			conn.close();
			return rownum;
	}
	
	
	public static int modificaBolla(Bolla bolla) throws Exception 
	{
		System.out.println("modificaBolla(Bolla bolla)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
		
		String sql =
		"UPDATE bolle SET tipo=?, marca=?, modello=?, accesincl=?, dataout=?, costo=?, preventivo=?, riparingaran=?, attesaricambi=?, riparato=?, note=?, difetto=?, giornigaran=?, reltec=? WHERE id = ?";		
				
				
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, bolla.getTipo());
		ps.setString(2, bolla.getMarca());
		ps.setString(3, bolla.getModello());
		ps.setString(4, bolla.getAccessori_inclusi());
		
		ps.setDate(5, bolla.getData_out_SQL());  
		
		ps.setInt(6, bolla.getCosto());
		ps.setBoolean(7, bolla.isPreventivo());
		ps.setBoolean(8, bolla.isRipari_in_garanzia());
		ps.setBoolean(9, bolla.isAttesa_ricambi());
		ps.setBoolean(10, bolla.isRiparato());
		ps.setString(11, bolla.getNote());
		ps.setString(12, bolla.getDifetto());
		ps.setInt(13, bolla.getGiorni_garanzia());
		ps.setString(14, bolla.getRelazione_tecnico());
		
		ps.setInt(15, bolla.getId());
		
		System.out.println(ps);
		
		int rownum = ps.executeUpdate();
		conn.close();
		return rownum;
	}

	public  int addBolla(Bolla bolla) throws Exception 
	{
		System.out.println("addBolla(Bolla bolla)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
			
		String sql = 			
		" INSERT INTO bolle(id_cliente, id_tecnico, tipo, marca, modello, accesincl, note, reltec, preventivo, riparingaran, attesaricambi, difetto)"+
		" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, bolla.getId_cliente());
		ps.setInt(2, bolla.getId_tecnico());
		ps.setString(3, bolla.getTipo());
		ps.setString(4, bolla.getMarca());
		ps.setString(5, bolla.getModello());
		ps.setString(6, bolla.getAccessori_inclusi());
		ps.setString(7, bolla.getNote());
		ps.setString(8, bolla.getRelazione_tecnico());
		ps.setBoolean(9, bolla.isPreventivo());
		ps.setBoolean(10, bolla.isRipari_in_garanzia());
		ps.setBoolean(11, bolla.isAttesa_ricambi());
		ps.setString(12, bolla.getDifetto());
		
		System.out.println(ps.toString());
		
		int rownum = ps.executeUpdate();
		
		if(rownum > 0)
		{
			ResultSet keys = ps.getGeneratedKeys();
			keys.next();  
			rownum = keys.getInt(1);
		}
		
		conn.close();
		return rownum;
	}
}
