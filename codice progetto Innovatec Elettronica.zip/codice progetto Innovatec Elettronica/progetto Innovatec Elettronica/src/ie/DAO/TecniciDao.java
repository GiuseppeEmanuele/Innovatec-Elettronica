package ie.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import ie.model.gestioneaccount.Tecnico;

public class TecniciDao 
{
	public static Tecnico cercaByCodFisPwd(String codFis, String pwd) throws Exception 
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from tecnici WHERE codfis=? AND pwd=?";
		
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		ps = conn.prepareStatement(sqlStr);
		ps.setString(1, codFis);
		ps.setString(2, pwd);
		
		
		ResultSet rset = ps.executeQuery();
		Tecnico t=null;
		
		if(rset.next())
		{
			t = new Tecnico();
			
			t.setId(rset.getString("id"));
			t.setPwd(rset.getString("pwd"));
			t.setNome(rset.getString("nome"));
			t.setCognome(rset.getString("cognome"));
			t.setCodfis(rset.getString("codfis"));
			t.setIndirizzo(rset.getString("indirizzo"));
			t.setEmail(rset.getString("email"));
			t.setTelefono(rset.getString("tel"));
			t.setNote(rset.getString("note"));
			t.setType(rset.getString("type"));
		}
		
		conn.close();
		
		return t;
		
	}

	public static Tecnico getTecnicoById(String id) throws Exception 
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from tecnici WHERE id=?";
		
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		ps.setString(1, id);
		
		ResultSet rset = ps.executeQuery();
		Tecnico t=null;
		
		if(rset.next())
		{
			t = new Tecnico();
			
			t.setId(rset.getString("id"));
			t.setPwd(rset.getString("pwd"));
			t.setNome(rset.getString("nome"));
			t.setCognome(rset.getString("cognome"));
			t.setCodfis(rset.getString("codfis"));
			t.setIndirizzo(rset.getString("indirizzo"));
			t.setEmail(rset.getString("email"));
			t.setTelefono(rset.getString("tel"));
			t.setNote(rset.getString("note"));
			t.setType(rset.getString("type"));
		}
		
		conn.close();
		
		return t;
		
	}

	public static ArrayList<Tecnico> getAllTecnici() throws Exception 
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from tecnici";
		
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		
		ResultSet rset = ps.executeQuery();
		ArrayList<Tecnico> tecnici = new ArrayList<Tecnico>();
		
		while(rset.next())
		{
			if(rset.getString("type").equals("admin")) continue;
			
			Tecnico t = new Tecnico();
			
			t.setId(rset.getString("id"));
			t.setPwd(rset.getString("pwd"));
			t.setNome(rset.getString("nome"));
			t.setCognome(rset.getString("cognome"));
			t.setCodfis(rset.getString("codfis"));
			t.setIndirizzo(rset.getString("indirizzo"));
			t.setEmail(rset.getString("email"));
			t.setTelefono(rset.getString("tel"));
			t.setNote(rset.getString("note"));
			t.setType(rset.getString("type"));
			
			tecnici.add(t);
		}
		
		conn.close();
		
		return tecnici;
		
	}
	
	
	

	public  int rimuoviTecnicoById(String id) throws Exception 
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", "");
		
			String sql = "DELETE FROM tecnici WHERE id=?;";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			
			int rownum = ps.executeUpdate();
			conn.close();
			return rownum;
		
	}
	
	public static int modificaTecnico(Tecnico tecnico) throws Exception 
	{
		
      System.out.println("modificaTecnico(Tecnico tecnico)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", "");
	
			
			
			String sql = "UPDATE tecnici SET pwd=?, nome=?, cognome=?, indirizzo=?, email=?, tel=?, note=? WHERE codfis = ?;";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, tecnico.getPwd());
			ps.setString(2, tecnico.getNome());
			ps.setString(3, tecnico.getCognome());
			ps.setString(4, tecnico.getIndirizzo());
			ps.setString(5, tecnico.getEmail());
			ps.setString(6, tecnico.getTelefono());
			ps.setString(7, tecnico.getNote());
			//ps.setString(8, tecnico.getType());
			ps.setString(8, tecnico.getCodfis());
			
			int rownum = ps.executeUpdate();
			conn.close();
			return rownum;
		
	}
	
	public  int addTecnico(Tecnico tecnico) throws Exception 
	{
		
       System.out.println("aggiungiTecnico(Tecnico tecnico)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", "");
	
	
			
			
			
			String sql = "SELECT * FROM tecnici WHERE codfis=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, tecnico.getCodfis());
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) return -2;
			
			sql = "INSERT INTO tecnici(pwd, codfis, nome, cognome, indirizzo, email, tel, note, type) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, tecnico.getPwd());
			ps.setString(2, tecnico.getCodfis());
			ps.setString(3, tecnico.getNome());
			ps.setString(4, tecnico.getCognome());
			ps.setString(5, tecnico.getIndirizzo());
			ps.setString(6, tecnico.getEmail());
			ps.setString(7, tecnico.getTelefono());
			ps.setString(8, tecnico.getNote());
			ps.setString(9, tecnico.getType());
			
			int rownum = ps.executeUpdate();

			conn.close();
			return rownum;
	
	}
}
