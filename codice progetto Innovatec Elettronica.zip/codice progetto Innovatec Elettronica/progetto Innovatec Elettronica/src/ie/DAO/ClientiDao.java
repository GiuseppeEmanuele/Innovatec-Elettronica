package ie.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;

public class ClientiDao 
{
	public static Cliente cercaByCodFisPwd(String codFis, String pwd) throws Exception 
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from clienti WHERE codfis=? AND pwd=?";
		
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		ps = conn.prepareStatement(sqlStr);
		ps.setString(1, codFis);
		ps.setString(2, pwd);
		Cliente c=null;
		
		System.out.println(ps.toString());
		
		ResultSet rset = ps.executeQuery(); 
		
		if(rset.next())
		{
			c = new Cliente();
			
			c.setId(rset.getString("id"));
			c.setPwd(rset.getString("pwd"));
			c.setNome(rset.getString("nome"));
			c.setCognome(rset.getString("cognome"));
			c.setCodfis(rset.getString("codfis"));
			c.setIndirizzo(rset.getString("indirizzo"));
			c.setEmail(rset.getString("email"));
			c.setTelefono(rset.getString("tel"));
			c.setNote(rset.getString("note"));
			
		}
		
		conn.close();
		
		return c;
		
	}

	public static ArrayList<Cliente> getClientiByIdTecnico(String idTecnico) throws Exception 
	{
		System.out.println("getClientiByIdTecnico(String idTecnico)");

		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from clienti WHERE id_tecnico="+idTecnico;
		ResultSet rset = conn.createStatement().executeQuery(sqlStr);  // Send the query to the server
		ArrayList<Cliente> clienti = new ArrayList<Cliente>();
		
		while(rset.next())
		{
			Cliente cliente = new Cliente();
			
			cliente.setId(rset.getString("id"));
			cliente.setId_tecnico(rset.getString("id_tecnico"));
			cliente.setCodfis(rset.getString("codfis"));
			cliente.setNome(rset.getString("nome"));
			cliente.setCognome(rset.getString("cognome"));
			cliente.setIndirizzo(rset.getString("indirizzo"));
			cliente.setEmail(rset.getString("email"));
			cliente.setTelefono(rset.getString("tel"));
			cliente.setNote(rset.getString("note"));
			
			clienti.add(cliente);
		}
		
		conn.close();
		return clienti;
		
	}

	public static ArrayList<Cliente> getAllClienti() throws Exception 
	{
		System.out.println("getAllClienti()");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from clienti";
		ResultSet rset = conn.createStatement().executeQuery(sqlStr);  // Send the query to the server
		ArrayList<Cliente> clienti = new ArrayList<Cliente>();
		
		while(rset.next())
		{
			Cliente cliente = new Cliente();
			
			cliente.setId(rset.getString("id"));
			cliente.setId_tecnico(rset.getString("id_tecnico"));
			cliente.setCodfis(rset.getString("codfis"));
			cliente.setNome(rset.getString("nome"));
			cliente.setCognome(rset.getString("cognome"));
			cliente.setIndirizzo(rset.getString("indirizzo"));
			cliente.setEmail(rset.getString("email"));
			cliente.setTelefono(rset.getString("tel"));
			cliente.setNote(rset.getString("note"));
			
			clienti.add(cliente);
		}
		
		conn.close();
		return clienti;
		
	}

	public static Cliente getClienteById(String id) throws Exception 
	{
		System.out.println("getClienteById(String id)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from clienti WHERE id="+id;
		ResultSet rset = conn.createStatement().executeQuery(sqlStr);  // Send the query to the server
		Cliente cliente = null;
		
		while(rset.next())
		{
			cliente = new Cliente();
			
			cliente.setId(rset.getString("id"));
			cliente.setId_tecnico(rset.getString("id_tecnico"));
			cliente.setCodfis(rset.getString("codfis"));
			cliente.setNome(rset.getString("nome"));
			cliente.setCognome(rset.getString("cognome"));
			cliente.setIndirizzo(rset.getString("indirizzo"));
			cliente.setEmail(rset.getString("email"));
			cliente.setTelefono(rset.getString("tel"));
			cliente.setNote(rset.getString("note"));
			cliente.setPwd(rset.getString("pwd"));
		}
		
		conn.close();
		return cliente;
		
	}
	
	public  int rimuoviClienteById(String id) throws Exception 
	{
			System.out.println("rimuoviClienteById(String id)");
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
			String sql = "DELETE FROM clienti WHERE id=?;";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			
			int rownum = ps.executeUpdate();
			conn.close();
			return rownum;
	}

	
	public int addCliente(Cliente cliente, Tecnico tecnico) throws Exception 
	{
		System.out.println("addCliente(Cliente cliente, Tecnico tecnico)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
			
		String sql = "SELECT * FROM clienti WHERE codfis=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, cliente.getCodfis());
		ResultSet rs = ps.executeQuery();
		if(rs.next()) return -2;
		
		sql = "INSERT INTO clienti(id_tecnico, codfis, nome, cognome, indirizzo, email, tel, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		
		ps = conn.prepareStatement(sql);
		ps.setInt(1, Integer.parseInt(tecnico.getId()));
		ps.setString(2, cliente.getCodfis());
		ps.setString(3, cliente.getNome());
		ps.setString(4, cliente.getCognome());
		ps.setString(5, cliente.getIndirizzo());
		ps.setString(6, cliente.getEmail());
		ps.setString(7, cliente.getTelefono());
		ps.setString(8, cliente.getNote());
		
		System.out.println(ps.toString());
		
		int rownum = ps.executeUpdate();
		return rownum;
	}

	public static int addCliente(Cliente cliente) throws Exception 
	{
		System.out.println("addCliente(Cliente cliente)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
			
		String sql = "SELECT * FROM clienti WHERE codfis=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, cliente.getCodfis());
		ResultSet rs = ps.executeQuery();
		if(rs.next()) return -2;
		
		sql = "INSERT INTO clienti(codfis, nome, cognome, indirizzo, email, tel, pwd) VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		ps = conn.prepareStatement(sql);
		ps.setString(1, cliente.getCodfis());
		ps.setString(2, cliente.getNome());
		ps.setString(3, cliente.getCognome());
		ps.setString(4, cliente.getIndirizzo());
		ps.setString(5, cliente.getEmail());
		ps.setString(6, cliente.getTelefono());
		ps.setString(7, cliente.getPwd());
		
		int rownum = ps.executeUpdate();
		return rownum;
	}

	
	public static int modificaClienteByCodfis(Cliente cliente) throws Exception 
	{
		System.out.println("modificaCliente(Cliente cliente)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
		String sql = "UPDATE clienti SET nome=?, cognome=?, indirizzo=?, email=?, tel=?, pwd=? WHERE codfis = ?;";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		
		ps.setString(1, cliente.getNome());
		ps.setString(2, cliente.getCognome());
		ps.setString(3, cliente.getIndirizzo());
		ps.setString(4, cliente.getEmail());
		ps.setString(5, cliente.getTelefono());
		ps.setString(6, cliente.getPwd());
		ps.setString(7, cliente.getCodfis());
		
		int rownum = ps.executeUpdate();
		return rownum;
	}



}
