package ie.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import ie.model.gestioneprodotti.Prodotto;

public class ProdottiDao 
{
	public static ArrayList<Prodotto> getAllProdotti() throws Exception 
	{
		System.out.println("ArrayList<Prodotto> getAllProdotti()");

		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
		
		//String sqlStr = "SELECT * FROM prodotti ORDER BY RAND()";
		String sqlStr = "SELECT * FROM prodotti ORDER BY id";
		
		PreparedStatement ps = conn.prepareStatement(sqlStr);
		
		ResultSet rset = ps.executeQuery();
		ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();
		
		while(rset.next())
		{
			Prodotto prodotto = new Prodotto();
			
			prodotto.setId(rset.getInt("id"));
			prodotto.setDescrizione(rset.getString("descrizione"));
			prodotto.setNome_img(rset.getString("nome_img"));
			prodotto.setCosto(rset.getDouble("costo"));
			
			prodotti.add(prodotto);
		}
		
		conn.close();
		return prodotti;
	}

	public static Prodotto getProdottoById(String id) throws Exception 
	{
		System.out.println("getProdottoById(String id)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!

		String sqlStr = "select * from prodotti WHERE id="+id;
		ResultSet rset = conn.createStatement().executeQuery(sqlStr);  // Send the query to the server
		Prodotto prodotto = null;
		
		while(rset.next())
		{
			prodotto = new Prodotto();
			
			prodotto.setId(rset.getInt("id"));
			prodotto.setCosto(rset.getDouble("costo"));
			prodotto.setDescrizione(rset.getString("descrizione"));
			prodotto.setNome_img(rset.getString("nome_img"));
		}
		
		conn.close();
		return prodotto;
		
	}

	
	
	public  int rimuoviProdottoById(String id) throws Exception 
	{
			System.out.println("rimuoviProdottoById(String id)");
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
			String sql = "DELETE FROM prodotti WHERE id=?;";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			
			int rownum = ps.executeUpdate();
			conn.close();
			return rownum;
	}

	public  int addProdotto(Prodotto prodotto) throws Exception 
	{
		System.out.println("addProdotto(Prodotto prodotto)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
		String sql = "INSERT INTO prodotti(descrizione, costo, nome_img) VALUES (?, ?, ?)";
		
		PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		ps.setString(1, prodotto.getDescrizione());
		ps.setDouble(2, prodotto.getCosto());
		ps.setString(3, prodotto.getNome_img());
		
		int rownum = ps.executeUpdate();
		
		ResultSet keys = ps.getGeneratedKeys();
		keys.next();  
		int key = keys.getInt(1);
		
		System.out.println("ID Prodotto: "+key);
		
		if(rownum>0) return key; 
		
		return 0;
	}

	
	public static int modificaProdottoById(Prodotto prodotto) throws Exception 
	{
		System.out.println("modificaProdottoById(Prodotto prodotto)");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
			
		String sql = "UPDATE prodotti SET costo=?, descrizione=?, nome_img=? WHERE id = ?;";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		
		ps.setDouble(1, prodotto.getCosto());
		ps.setString(2, prodotto.getDescrizione());
		ps.setString(3, prodotto.getNome_img());
		ps.setInt(4, prodotto.getId());
		
		int rownum = ps.executeUpdate();
		return rownum;
	}

	

}
