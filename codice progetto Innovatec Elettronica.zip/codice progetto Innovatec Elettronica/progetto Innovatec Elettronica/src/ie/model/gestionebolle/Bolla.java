package ie.model.gestionebolle;

import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Bolla 
{
	
	private int id;
	private int id_cliente;
	private int id_tecnico;
	private String tipo;
	private String marca;
	private String modello;
	private int costo;
	private String relazione_tecnico;
	private boolean preventivo;
	private boolean riparato;
	private String difetto;
	
	private String note;
	private String data_in;
	private String data_out;
	private String accessori_inclusi;
	private int giorni_garanzia;
	private boolean ripari_in_garanzia;
	private boolean attesa_ricambi;
	
	public Bolla()
	{
		 id=0;
		 id_cliente=0;
		 id_tecnico=0;
		 tipo="";
		 marca="";
		 modello="";
		 accessori_inclusi="";
		 data_in="";
		 data_out="";
		 note="";
		 costo=0;
		 relazione_tecnico="";
		 preventivo=false;
		 giorni_garanzia=0;
		 ripari_in_garanzia=false;
	     attesa_ricambi=false;
		 riparato=false;
		 difetto="";
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_cliente() {
		return id_cliente;
	}

	public void setId_cliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}

	public int getId_tecnico() {
		return id_tecnico;
	}

	public void setId_tecnico(int id_tecnico) {
		this.id_tecnico = id_tecnico;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public String getAccessori_inclusi() {
		return accessori_inclusi;
	}

	public void setAccessori_inclusi(String accessori_inclusi) {
		this.accessori_inclusi = accessori_inclusi;
	}

	public String getData_in() 
	{
		if(data_in.equals("")) return data_in;
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date date = null;
		try {
			date = format.parse(data_in);
		} catch (ParseException e) 
		{
			e.printStackTrace();
		}
		format = new SimpleDateFormat("dd/MM/yyyy");
		return format.format(date);
	}

	public void setData_in(String data_in) {
		this.data_in = data_in;
	}

	public String getData_out() 
	{
		if(data_out==null || data_out.equals("")) return "";
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date date = null;
		try {
			date = format.parse(data_out);
		} catch (ParseException e) 
		{
			e.printStackTrace();
		}
		format = new SimpleDateFormat("dd/MM/yyyy");
		return format.format(date);
	}

	public java.sql.Date getData_out_SQL() 
	{
		if(data_out==null || data_out.equals("")) return null;
		
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date date = null;
		try {
			date = format.parse(data_out);
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			return sqlDate;
		} catch (ParseException e) 
		{
			e.printStackTrace();
		}
		format = new SimpleDateFormat("dd/MM/yyyy");
		return null;
	}

	
	

	public void setData_out(String data_out) {
		this.data_out = data_out;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public int getCosto() {
		return costo;
	}

	public void setCosto(int costo) {
		this.costo = costo;
	}

	public String getRelazione_tecnico() {
		return relazione_tecnico;
	}

	public void setRelazione_tecnico(String relazione_tecnico) {
		this.relazione_tecnico = relazione_tecnico;
	}

	public boolean isPreventivo() {
		return preventivo;
	}

	public void setPreventivo(boolean preventivo) {
		this.preventivo = preventivo;
	}

	public int getGiorni_garanzia() {
		return giorni_garanzia;
	}

	public void setGiorni_garanzia(int giorni_garanzia) {
		this.giorni_garanzia = giorni_garanzia;
	}

	public boolean isAttesa_ricambi() {
		return attesa_ricambi;
	}

	public void setAttesa_ricambi(boolean attesa_ricambi) {
		this.attesa_ricambi = attesa_ricambi;
	}

	public boolean isRiparato() {
		return riparato;
	}

	public void setRiparato(boolean riparato) {
		this.riparato = riparato;
	}
	
	public boolean isRipari_in_garanzia() {
		return ripari_in_garanzia;
	}

	public void setRipari_in_garanzia(boolean ripari_in_garanzia) {
		this.ripari_in_garanzia = ripari_in_garanzia;
	}

	public String getDifetto() {
		return difetto;
	}
	
	public void setDifetto(String difetto) {
		this.difetto = difetto;
	}
	
	
	

}
