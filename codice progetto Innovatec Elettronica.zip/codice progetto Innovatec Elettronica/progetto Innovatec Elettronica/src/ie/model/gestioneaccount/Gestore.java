package ie.model.gestioneaccount;

public class Gestore extends Tecnico
{
	public Gestore()
	{}
}
