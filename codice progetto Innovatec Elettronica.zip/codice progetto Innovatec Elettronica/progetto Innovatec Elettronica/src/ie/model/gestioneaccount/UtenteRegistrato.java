package ie.model.gestioneaccount;

public class UtenteRegistrato
{
	private String id;
	private String codfis;
	private String pwd;
	
	public UtenteRegistrato()
	{
	   id="";
	   pwd="";
	   codfis="";
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return pwd;
	}



	public void setPwd(String pwd) {
		this.pwd = pwd;
	}



	public String getCodfis() {
		return codfis;
	}



	public void setCodfis(String codFis) {
		this.codfis = codFis;
	}


}
