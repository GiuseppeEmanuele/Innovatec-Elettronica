package ie.model.gestionevendita;

import java.util.ArrayList;
import java.util.Iterator;

import ie.model.gestioneprodotti.Prodotto;

public class Carrello 
{
	private ArrayList<Prodotto> prodotti;
	
	public Carrello()
	{
		prodotti = new ArrayList<Prodotto>();
	}
	
	public void addProdotto(Prodotto p)
	{
		prodotti.add(p);
	}
	
	public Prodotto remProdotto(int id)
	{
		Iterator<Prodotto> it = prodotti.iterator();
		
		
		for( ; it.hasNext() ; )
		{
			Prodotto p = it.next();
			if(p.getId()==id)
			{
				prodotti.remove(p);
				return p;
			}
		}

		return null;
	}
	
	public ArrayList<Prodotto> getListaProdotti()
	{
		return prodotti;
	}
	
	public boolean esisteProdotto(int id)
	{
		Iterator<Prodotto> it = prodotti.iterator();
		
		for( ; it.hasNext() ; )
		{
			Prodotto p = it.next();
			if(p.getId()==id) return true;
		}

		return false;
		
	}
	
	public double getCostoTotale()
	{
		Iterator<Prodotto> it = prodotti.iterator();
		
		double costoTotale = 0;
		
		for( ; it.hasNext() ; )
		{
			Prodotto p = it.next();
			costoTotale+=p.getCosto();
		}

		return costoTotale;
		
	}
	
	

}
