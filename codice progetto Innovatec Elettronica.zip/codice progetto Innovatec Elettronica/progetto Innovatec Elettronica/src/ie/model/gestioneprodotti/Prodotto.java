package ie.model.gestioneprodotti;

public class Prodotto 
{
	private int id;
	private String descrizione;
	private String nome_img;
	private double costo;
	private int costo_spedizione;
	
	
	public Prodotto()
	{
		id=0;
		descrizione="";
		nome_img="";
		costo=0;
		costo_spedizione=0;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public String getNome_img() {
		return nome_img;
	}
	public void setNome_img(String nome_img) {
		this.nome_img = nome_img;
	}
	public Double getCosto() {
		return costo;
	}
	public void setCosto(Double costo) {
		this.costo = costo;
	}


	public int getCosto_spedizione() {
		return costo_spedizione;
	}


	public void setCosto_spedizione(int costo_spedizione) {
		this.costo_spedizione = costo_spedizione;
	}

	
	

}
