package ie.test.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class DriverManagerConnectionPoolTest {
    
    public DriverManagerConnectionPoolTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getConnection method, of class DriverManagerConnectionPool.
     * @throws java.lang.Exception
     */
    @Test
    public void testGetConnection() throws Exception 
    {
        System.out.println("getConnection");
        
        String dbUrl = "jdbc:mysql://localhost:3306/progettoPW";
   
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/progettoPW", "root", ""); // <== Check!
        
		assertNotNull(conn);
		assertEquals(dbUrl, conn.getMetaData().getURL());
        
        
    }
    
}
