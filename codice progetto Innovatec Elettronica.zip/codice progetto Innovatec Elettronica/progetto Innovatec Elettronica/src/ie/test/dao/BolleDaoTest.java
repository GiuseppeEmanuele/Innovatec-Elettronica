package ie.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import ie.DAO.BolleDao;
import ie.DAO.ProdottiDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestionebolle.Bolla;
import ie.model.gestionebolle.Bolla;

public class BolleDaoTest 
{
	private BolleDao bd;
	private Bolla b;
	
	@Before
	public void setUp() throws Exception 
	{
		bd = new BolleDao();
		assertNotNull(bd);
		
		b = new Bolla();
		b.setTipo("Bolla di Test");
		b.setMarca("Marca di prova");
		b.setModello("Modello di prova");
		b.setId_cliente(23);  // id cliente scelto tra quelli esistenti per permettere il test
		b.setId_tecnico(2); //  id tecnico scelto tra quelli esistenti per permettere il test
        b.setNote("Note bolle test");
        b.setRelazione_tecnico("Relazione Tecnico test");
        b.setDifetto("Difetto test");
        b.setCosto(250);
        
		assertNotNull(b);
	}
	
	@After
	public void tearDown() throws Exception 
	{
		
	}
	
	
	@Test
	public void test()
	{
		testAddBolla();
	   // testModificaBolla();
	 // testRimuoviBollaById();
	  //  testGetBollaById();
	  //  testCercaBollaByIdCodFis();
	}	

	public void testAddBolla() 
	{
		try 
		{
			assertEquals(1, bd.addBolla(b));
		}
		
		catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
	public void testModificaBolla() 
	{
		try 
		{
			    Bolla b = bd.getBollaById("18");  // id bolla esistente e vadoa prendere  quello della bolla creata come test
	    	  //Bolla b = bd.getBollaById("50");  // per condizione di falimento id non esistente il test fallisce
	    		
	    		b.setCosto(250);
	    		b.setMarca("Modifica222 Marca test");
	    		b.setModello("Modifica222 modello test");
	    		b.setTipo("Modifica tipo222 test");
	    		
	    		int modifica = bd.modificaBolla(b);
	    		
	    		b = bd.getBollaById("18"); //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
	    		
	    		assertEquals(250, b.getCosto());
	    		assertEquals("Modifica222 Marca test", b.getMarca());
	    		assertEquals("Modifica222 modello test", b.getModello());
	    		assertEquals("Modifica222 tipo test", b.getTipo());
	    		
	    	
	    	   //assertTrue(modifica>0);
	    	
	    	   //assertTrue(modifica<0); //fallisce
		}
		
		catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
	public void testRimuoviBollaById()
	{
		try 
		{
			assertEquals(1, bd.rimuoviBollaById("18")); //id bolla di test appena creata
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
	public void testGetBollaById()
    {
    	try 
		{
    		b = bd.getBollaById("10");
    		assertNotNull(b);
			
    		//b = bd.getBollaById("35"); // id bolla non esistente quindi il test fallisce 
    		//assertNotNull(b);
    		
    		
			
		} catch (Exception e)
		{
			fail(e.getMessage());
		}
    }
	
	public void testCercaBollaByIdCodFis() 
	{
		try 
		{
			b = bd.cercaBollaByIdCodfis("18", "SCLCRL79R11A509W");
			assertNotNull(b);
			assertFalse(String.valueOf(b.getId()).equals(""));
			
			//assertNotNull(null);
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}

	
	
	    


}
