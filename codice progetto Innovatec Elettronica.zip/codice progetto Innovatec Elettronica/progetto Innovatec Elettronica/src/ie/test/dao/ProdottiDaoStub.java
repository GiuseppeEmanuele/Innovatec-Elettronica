package ie.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import ie.DAO.BolleDao;
import ie.DAO.ClientiDao;
import ie.DAO.ProdottiDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;
import ie.model.gestioneprodotti.Prodotto;

public class ProdottiDaoStub extends ProdottiDao
{
	@Override
	public int addProdotto(Prodotto prodotto) throws Exception 
	{
		return 1;
	}
	
	@Override
	public int rimuoviProdottoById(String id)
	{
	    return 1;	
	}

  

}
