
package ie.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import ie.DAO.ProdottiDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneprodotti.Prodotto;

public class ProdottiDaoTest 
{
	private ProdottiDao pd;
	private Prodotto p;
	
	@Before
	public void setUp() throws Exception 
	{
		pd = new ProdottiDao();
		assertNotNull(pd);
		
		p = new Prodotto();
		p.setDescrizione("Marca e modello oggetto di prova");
		p.setNome_img("nome_img oggetto di prova");
		p.setCosto(100.0);
		

		assertNotNull(p);
	}
	
	@After
	public void tearDown() throws Exception 
	{
		
	}
	
	
	@Test
	public void test()
	{
		//testAddProdotto();
		//testRimuoviProdottoById();
		//testGetProdottoById();
		//testGetAllProdotti();

		testmodificaProdottoById();
		
	}	

	public void testAddProdotto() 
	{
		try 
		{
			int id_prodotto = pd.addProdotto(p);
			p.setId(id_prodotto);
			
			assertTrue(id_prodotto>0);
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}

	
	public void testRimuoviProdottoById()
	{
		try 
		{
			
			assertEquals(1, pd.rimuoviProdottoById(String.valueOf(p.getId())));
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
    public void testGetProdottoById()
    {
    	try 
		{
    		
    		p = pd.getProdottoById("6");
    		assertNotNull(p);
			
    		//p = cd.getProdottoById("30"); // id cliente non esistente quindi il test fallisce 
    		//assertNotNull(p);
			
    		
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
    }
	
    public void testGetAllProdotti()
    {
    	try 
		{
    		
            ArrayList<Prodotto> prodotti = pd.getAllProdotti();
    		
    		assertTrue(prodotti.size()>0);
			 
    		//assertTrue(prodotti.size()<0); // fallisce
    		
    		
		} catch (Exception e) 
    	
		{
			fail(e.getMessage());
		}
    	
    }
    
    
    
    public void testmodificaProdottoById()
    {
    	try 
		{
    		
    		Prodotto p = pd.getProdottoById("6");
      	  //Prodotto p = pd.getProdottoById("55");  // per condizione di falimento id non esistente il test fallisce
      		
      		p.setCosto(550.0);
      		
      		int modifica = pd.modificaProdottoById(p);
      		
      		assertEquals(1, modifica);
      		
      		p=pd.getProdottoById("6");// riprendo il prodotto con gli eventuali campi modificati e vado a fare il controllo
      		
      		assertEquals(Double.valueOf(550), p.getCosto());
      		
      	
      	   //assertTrue(modifica>0);
      	
      	   //assertTrue(modifica<0); //fallisce
      		
    		
			
		} catch (Exception e)
		{
			fail(e.getMessage());
		}
    }
    
    


}
