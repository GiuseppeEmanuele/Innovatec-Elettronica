package ie.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import ie.DAO.BolleDao;
import ie.DAO.ClientiDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestionebolle.Bolla;

public class BolleDaoStub extends BolleDao
{
	@Override
	public int addBolla(Bolla bolla) throws Exception 
	{
		return 1;
	}
	
	@Override
	public int rimuoviBollaById(String id)
	{
	    return 1;	
	}

  

}
