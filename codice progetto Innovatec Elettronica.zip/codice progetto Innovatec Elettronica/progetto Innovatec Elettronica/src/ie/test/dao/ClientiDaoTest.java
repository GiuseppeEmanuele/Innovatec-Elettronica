package ie.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import ie.DAO.ClientiDao;
import ie.model.gestioneaccount.Cliente;

public class ClientiDaoTest 
{
	private ClientiDao cd;
	private Cliente c;
	
	@Before
	public void setUp() throws Exception 
	{
		cd = new ClientiDao();
		assertNotNull(cd);
		
		c = new Cliente();
		c.setCodfis("aaasss85t25a968t");
		c.setNome("Pippo");
		c.setCognome("Pippo");
		c.setIndirizzo("via Pluto");
		c.setEmail("provamailcliente@test.it");
		c.setTelefono("3552798652");
		c.setPwd("passwordTestCliente");

		assertNotNull(c);
	}
	
	@After
	public void tearDown() throws Exception 
	{
		
	}
	

	
	@Test
	public void test()
	{
		/*
		testRimuoviClienteById();
		testGetAllClienti();
		testGetClientiByIdTecnico();
		testAddCliente();
		testCercaByCodFisPwd();
		testGetClienteById();
		testmodificaClienteByCodfis();
		*/
	}	

	public void testAddCliente() 
	{
		try 
		{
			assertEquals(1, cd.addCliente(c));
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}

	public void testCercaByCodFisPwd() 
	{
		try 
		{
			c = cd.cercaByCodFisPwd(c.getCodfis(), c.getPwd());
			assertNotNull(c);
			assertFalse(c.getId().equals(""));
			
			//assertNotNull(null);
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
	public void testRimuoviClienteById()
	{
		try 
		{
			assertEquals(1, cd.rimuoviClienteById(c.getId()));
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
    public void testGetClientiByIdTecnico()
    {
    	try 
		{
    		ArrayList<Cliente> clienti = cd.getClientiByIdTecnico("2");
    		//ArrayList<Cliente> clienti = cd.getClientiByIdTecnico("50"); // condizione per fallimento
			
    		for(int i=0; i<clienti.size(); i++)
    		{
    			assertEquals("2", clienti.get(i).getId_tecnico());
    		}
    		
    		//assertTrue(clienti.size()>0);  si pu� verificare la size dell'arrayList per verificare la correttezza del metodo
    	
    		//assertTrue(clienti.size()<0); //  fallisce  
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
    }
    
    public void testGetAllClienti()
    {
    	try 
		{
    		ArrayList<Cliente> clienti = cd.getAllClienti();
    		
    		assertTrue(clienti.size()>0);
			 
    		//assertTrue(clienti.size()<0); // fallisce
			
		} catch (Exception e) 
    	
		{
			fail(e.getMessage());
		}
    	
    }
    
    public void testGetClienteById()
    {
    	try 
		{
    		c = cd.getClienteById("17");
    		assertNotNull(c);
			
    		//c = cd.getClienteById("30"); // id cliente non esistente quindi il test fallisce 
    		//assertNotNull(c);
    		
    		
			
		} catch (Exception e)
		{
			fail(e.getMessage());
		}
    }
    
    public void testmodificaClienteByCodfis()
    {
    	try 
		{
    		Cliente c = cd.getClienteById("18");
    	  //Cliente c = cd.getClienteById("50");  // per condizione di falimento id non esistente il test fallisce
    		
    		c.setNome("Giuseppe");
    		c.setCognome("Pezzillo");
    		
    		int modifica = cd.modificaClienteByCodfis(c);
    		
    		c = cd.getClienteById("18"); //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
    		
    		assertEquals("Giuseppe", c.getNome());
    		assertEquals("Pezzillo", c.getCognome());
    		
    	
    	   //assertTrue(modifica>0);
    	
    	   //assertTrue(modifica<0); //fallisce
    		
			
		} catch (Exception e)
		{
			fail(e.getMessage());
		}
    }
    
    


}
