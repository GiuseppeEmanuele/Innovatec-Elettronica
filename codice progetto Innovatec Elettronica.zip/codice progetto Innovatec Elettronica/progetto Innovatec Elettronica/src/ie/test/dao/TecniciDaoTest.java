package ie.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import ie.DAO.TecniciDao;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;

public class TecniciDaoTest 
{
	private TecniciDao td;
	private Tecnico t;
	
	@Before
	public void setUp() throws Exception 
	{
		td = new TecniciDao();
		assertNotNull(td);
		
		t = new Tecnico();
		t.setCodfis("tttsss97t52a256t");
		t.setNome("Andrea");
		t.setCognome("Scotti");
		t.setIndirizzo("via Roma");
		t.setEmail("provamailtecnico@test.it");
		t.setTelefono("3442185930");
		t.setNote("Prova note");
		t.setPwd("passwordTestTecnico");

		assertNotNull(t);
	}
	
	@After
	public void tearDown() throws Exception 
	{
		
	}
	
	
	@Test
	public void test()
	{
	
	//	testAddTecnico();
	//	testCercaByCodFisPwd();
	//	testGetTecnicoById();
	//	testGetAllTecnici();
	//	testRimuoviTecnicoById();
	//	testmodificaTecnico();
		
	}	

	public void testAddTecnico() 
	{
		try 
		{
			assertEquals(1, td.addTecnico(t));
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}

	public void testCercaByCodFisPwd() 
	{
		try 
		{
			t = td.cercaByCodFisPwd(t.getCodfis(), t.getPwd());
			assertNotNull(t);
			assertFalse(t.getId().equals(""));
			
			//assertNotNull(null);
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
	public void testRimuoviTecnicoById()
	{
		try 
		{
			assertEquals(1, td.rimuoviTecnicoById("10"));  // id esistente del tecnico di prova appena creato
			
			// fallimento con id non esistente
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
	
    public void testGetTecnicoById()
    {
    	try 
		{
    		t = td.getTecnicoById("6");
    		assertNotNull(t);
			
    		//t = td.getTecnicoById("30"); // id tecnico non esistente quindi il test fallisce 
    		//assertNotNull(t);
    		
    		
			
    		
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
    }
	
    public void testGetAllTecnici()
    {
    	try 
		{
    		ArrayList<Tecnico> tecnici = td.getAllTecnici();
    		
    		assertTrue(tecnici.size()>0);
			 
    		//assertTrue(tecnici.size()<0); // fallisce
			
		} catch (Exception e) 
    	
		{
			fail(e.getMessage());
		}
    	
    }
    
    public void testGetClienteById()
    {
    	try 
		{
    		t = td.getTecnicoById("7");
    		assertNotNull(t);
			
    		//t = td.getTecnicoById("55"); // id tecnico non esistente quindi il test fallisce 
    		//assertNotNull(t);
    		
    		
			
		} catch (Exception e)
		{
			fail(e.getMessage());
		}
    }
    
    public void testmodificaTecnico()
    {
    	try 
		{
    		Tecnico t = td.getTecnicoById("7");
      	  //Tecnico t = td.getTecnicoById("50");  // per condizione di falimento id non esistente il test fallisce
      		
      		t.setNome("Giuseppe");
      		t.setCognome("Napolitano");
      		
      		int modifica = td.modificaTecnico(t);
      		
      		t = td.getTecnicoById("7"); //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
      		
      		assertEquals("GiuseppeEmanuele", t.getNome());
      		assertEquals("Nappi", t.getCognome());
      		
      	
      	   //assertTrue(modifica>0);
      	
      	   //assertTrue(modifica<0); //fallisce
    		
			
		} catch (Exception e)
		{
			fail(e.getMessage());
		}
    }
    
    


}
