package ie.test.managers;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import ie.DAO.ClientiDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.manager.gestioneautenticazione.ManagerAutenticazione;
import ie.manager.gestionebolle.ManagerBolle;
import ie.manager.gestioneprodotti.ManagerProdotti;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestioneaccount.UtenteRegistrato;
import ie.model.gestionebolle.Bolla;
import ie.model.gestioneprodotti.Prodotto;


//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ManagerProdottiTest {
    
    Prodotto p;
   
    public ManagerProdottiTest() 
    {
    	
    }
    
    @Test
    public void Test()
    {
    	nuovoProdottoTest();
    	rimuoviProdottoTest();
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp()
    {
		
		p = new Prodotto();
		
		p.setDescrizione("Marca e modello oggetto di prova");
		p.setNome_img("nome_img oggetto di prova");
		p.setCosto(100.0);
        
		assertNotNull(p);
		
    }
    
    @After
    public void tearDown() {
    }
    
    public void nuovoProdottoTest() 
	{
		try 
		{
			ManagerProdotti mp = new ManagerProdotti();
			
			
			int ris = mp.nuovoProdotto(p);
			
			assertTrue(ris>0); 
			
			p.setId(ris);
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
    
    
    
    public void rimuoviProdottoTest() 
	{
		try 
		{
			ManagerProdotti mp = new ManagerProdotti();
			
			int ris = mp.rimuoviProdotto(String.valueOf(p.getId()));
			 
			assertEquals(1, ris);
			
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
    
   
}