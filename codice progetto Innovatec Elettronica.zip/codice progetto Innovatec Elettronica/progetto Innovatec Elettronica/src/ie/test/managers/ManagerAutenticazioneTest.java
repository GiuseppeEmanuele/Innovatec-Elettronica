package ie.test.managers;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import ie.DAO.ClientiDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.manager.gestioneautenticazione.ManagerAutenticazione;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestioneaccount.UtenteRegistrato;


//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ManagerAutenticazioneTest {
    
   
   
    public ManagerAutenticazioneTest() 
    {
    	
    }
    
    @Test
    public void Test()
    {
       	loginCheckTest();
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp()
    {
		
		
		
    }
    
    @After
    public void tearDown() {
    }
    
   
    public void loginCheckTest()
   	{
   		try 
   		{
   			
   			ManagerAutenticazione mAut = new ManagerAutenticazione();
   			
   			UtenteRegistrato ut = mAut.loginCheck("AAAAAA22W22W222W", "gep97"); // cliente gi� presente nel database
   			
   			assertNotNull(ut);
   	
   			
   		} catch (Exception e) 
   		{
   			System.out.println(e.getMessage());
   			fail(e.getMessage());
   		}
   	}

   
}
