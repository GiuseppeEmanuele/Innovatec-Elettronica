package ie.test.managers;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import ie.DAO.ClientiDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.manager.gestioneautenticazione.ManagerAutenticazione;
import ie.manager.gestionebolle.ManagerBolle;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestioneaccount.UtenteRegistrato;
import ie.model.gestionebolle.Bolla;


//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ManagerBolleTest {
    
    Bolla b;
   
    public ManagerBolleTest() 
    {
    	
    }
    
    @Test
    public void Test()
    {
    	
    	nuovaModificaBollaTest();
    	rimuoviBollaTest();
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp()
    {
		
		b = new Bolla();
		
		b.setTipo("Bolla di Test");
		b.setMarca("Marca di prova");
		b.setModello("Modello di prova");
		b.setId_cliente(23);  // id cliente scelto tra quelli esistenti per permettere il test
		b.setId_tecnico(7); //  id tecnico scelto tra quelli esistenti per permettere il test
        b.setNote("Note bolle test");
        b.setRelazione_tecnico("Relazione Tecnico test");
        b.setDifetto("Difetto test");
        b.setCosto(250);
        
		assertNotNull(b);
		
    }
    
    @After
    public void tearDown() {
    }
    
    public void rimuoviBollaTest() 
	{
		try 
		{
			ManagerBolle mb = new ManagerBolle();
			
			int ris = mb.rimuoviBolla(String.valueOf(b.getId())); 
			
			System.out.println(ris);
			  
			assertEquals(1, ris);
			
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
    
    public void nuovaModificaBollaTest() 
   	{
   		try 
   		{
   			ManagerBolle mb = new ManagerBolle();
            ManagerAutenticazione mAut = new ManagerAutenticazione();
   			
   			UtenteRegistrato ut = mAut.loginCheck("SSSSSS45D22W222R", "dado97"); // tecncio gi� presente nel database
   			Tecnico t = (Tecnico) ut;
   			
   			assertNotNull(ut);

   			
   			int ris = mb.nuovaModificaBolla(b, t);
      		assertTrue(ris>0);
   			b.setId(ris);
      		
      			
   		} 
   		catch (Exception e) 
   		{
   			fail(e.getMessage());
   		}
   	}
    
   

   
}