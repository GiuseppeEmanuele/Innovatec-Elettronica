package ie.test.managers;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import ie.DAO.ClientiDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.manager.gestioneautenticazione.ManagerAutenticazione;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestioneaccount.UtenteRegistrato;


//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ManagerAccountTest {
    
    Cliente c;
    Tecnico t;
   
    public ManagerAccountTest() 
    {
    	
    }
    
    @Test
    public void Test()
    {
    	//aggiungiClienteTest();
    	//modificaClienteTest();
        //rimuoviClienteTest();
    	//aggiungiTecnicoTest();
    	//modificaTecnicoTest();
    	//rimuoviTecnicoTest();
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp()
    {
		
		c = new Cliente();
		c.setCodfis("aaasss85t25a968t");
		c.setNome("Pippo");
		c.setCognome("Pippo");
		c.setIndirizzo("via Pluto");
		c.setEmail("provamailcliente@test.it");
		c.setTelefono("3552798652");
		
		t = new Tecnico();
		t.setCodfis("tttsss97t52a256t");
		t.setNome("Andrea");
		t.setCognome("Scotti");
		t.setIndirizzo("via Roma");
		t.setEmail("provamailtecnico@test.it");
		t.setTelefono("3442185930");
		t.setNote("Prova note");
		t.setPwd("passwordTestTecnico");
		
    }
    
    @After
    public void tearDown() {
    }
    
    public void aggiungiClienteTest() 
	{
		try 
		{
			ManagerAccount ma = new ManagerAccount();
			
			t.setId("2");  // Cliente aggiunto da quel tecnico
			
			int ris = ma.aggiungiCliente(c, t);
			
			assertEquals(1, ris);
			
			
		} catch (Exception e) 
		{
			fail(e.getMessage());
		}
	}
    
    public void modificaClienteTest() 
   	{
   		try 
   		{
   			ManagerAccount ma = new ManagerAccount();
   			
   			c.setNome("ModificaPippo");
   			c.setCognome("ModificaPippo");

   			ma.modificaCliente(c);
      		
      		Cliente modCliente = c; //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
      		
      		assertEquals("ModificaPippo", modCliente.getNome());
      		assertEquals("ModificaPippo", modCliente.getCognome());
      		
   			
   			
   		} catch (Exception e) 
   		{
   			fail(e.getMessage());
   		}
   	}
    
    public void rimuoviClienteTest()
	{
		try 
		{
			 ManagerAccount ma = new ManagerAccount();
			 ManagerAutenticazione mAut= new ManagerAutenticazione();
			 
			 UtenteRegistrato ut = mAut.loginCheck("aaasss85t25a968t",""); // pwd vuota perch� il cliente viene aggiunto dal tecnico
			 
			 String idClienteDaRimuovere = ut.getId();
			
			 assertEquals(1, ma.rimuoviCliente(idClienteDaRimuovere));
			
	
			
		} catch (Exception e) 
		{
			System.out.println(e.getMessage());
			fail(e.getMessage());
		}
	}

    public void aggiungiTecnicoTest() 
  	{
  		try 
  		{
  			ManagerAccount ma = new ManagerAccount();
  			
  			int ris = ma.aggiungiTecnico(t);
  			
  			assertEquals(1, ris);
  			
  			
  		} catch (Exception e) 
  		{
  			fail(e.getMessage());
  		}
  	}
    
    public void modificaTecnicoTest() 
   	{
   		try 
   		{
   			ManagerAccount ma = new ManagerAccount();
   			
   			t.setNome("ModificaAndrea");
   			t.setCognome("ModificaScotti");

   			ma.modificaTecnico(t);
      		
      		Tecnico modTecnico = t; //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
      		
      		assertEquals("ModificaAndrea", modTecnico.getNome());
      		assertEquals("ModificaScotti", modTecnico.getCognome());
      		
   			
   			
   		} catch (Exception e) 
   		{
   			fail(e.getMessage());
   		}
   	}
    
    public void rimuoviTecnicoTest()
   	{
   		try 
   		{
   			 ManagerAccount ma = new ManagerAccount();
   			 ManagerAutenticazione mAut= new ManagerAutenticazione();
   			 
   			 UtenteRegistrato ut = mAut.loginCheck("tttsss97t52a256t","passwordTestTecnico");
   			 
   			 String idTecnicoDaRimuovere = ut.getId();
   			
   			 assertEquals(1, ma.rimuoviTecnico(idTecnicoDaRimuovere));
   			
   	
   			
   		} catch (Exception e) 
   		{
   			System.out.println(e.getMessage());
   			fail(e.getMessage());
   		}
   	}

   
}