package ie.test.managers;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import ie.DAO.ClientiDao;
import ie.manager.gestioneaccount.ManagerAccount;
import ie.manager.gestioneaccount.ManagerProfilo;
import ie.manager.gestioneautenticazione.ManagerAutenticazione;
import ie.model.gestioneaccount.Cliente;
import ie.model.gestioneaccount.Tecnico;
import ie.model.gestioneaccount.UtenteRegistrato;


//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ManagerProfiloTest {
    
    Cliente c;
    Tecnico t;
   
    public ManagerProfiloTest() 
    {
    	
    }
    
    @Test
    public void Test()
    {
    	
    	//modificaProfiloClienteTest();
    	//modificaProfiloTecnicoTest();
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp()
    {
		
    }
    
    @After
    public void tearDown() {
    }
    
   
    
    public void modificaProfiloClienteTest() 
   	{
   		try 
   		{
   			ManagerProfilo mp = new ManagerProfilo();
   			ManagerAutenticazione mAut = new ManagerAutenticazione();
   			
   			Cliente c =(Cliente) mAut.loginCheck("SCLCRL79R11A509E", "carlo67");
   			
   			c.setNome("Carlo");
   			c.setCognome("Grasso");

   			mp.modificaProfiloCliente(c);
      		
      		Cliente modCliente = c; //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
      		
      		assertEquals("Carlo", modCliente.getNome());
      		assertEquals("Grasso", modCliente.getCognome());
      		
   			
   			
   		} catch (Exception e) 
   		{
   			fail(e.getMessage());
   		}
   	}
    
   public void modificaProfiloTecnicoTest() 
   	{
   		try 
   		{
   			ManagerProfilo mp = new ManagerProfilo();
   			ManagerAutenticazione mAut = new ManagerAutenticazione();
   			
   			Tecnico t =(Tecnico) mAut.loginCheck("TTTTTT45W22W222P", "1234bliz");
   			
   			t.setNome("ModificaPasquale");
   			t.setCognome("ModificaImola");

   			mp.modificaProfiloTecnico(t);
      		
      		Tecnico modTecnico = t; //riprendo l'oggetto modificato e vado a verificarmi se i campi sono stati modificati effettivamente
      		
      		assertEquals("ModificaPasquale", modTecnico.getNome());
      		assertEquals("ModificaImola", modTecnico.getCognome());
      		
   			
   			
   		} catch (Exception e) 
   		{
   			fail(e.getMessage());
   		}
   	}
    
   
   
}