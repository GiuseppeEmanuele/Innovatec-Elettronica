-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Dic 31, 2018 alle 22:46
-- Versione del server: 10.1.21-MariaDB
-- Versione PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `progettopw`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `bolle`
--

CREATE TABLE `bolle` (
  `id` int(8) UNSIGNED NOT NULL,
  `id_cliente` int(8) UNSIGNED DEFAULT NULL,
  `id_tecnico` int(8) DEFAULT NULL,
  `tipo` char(100) DEFAULT NULL,
  `marca` char(100) DEFAULT NULL,
  `modello` char(100) DEFAULT NULL,
  `accesincl` char(200) DEFAULT NULL,
  `datain` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `dataout` timestamp NULL DEFAULT NULL,
  `note` varchar(3072) DEFAULT NULL,
  `costo` double UNSIGNED DEFAULT NULL,
  `reltec` varchar(3072) DEFAULT NULL,
  `preventivo` bit(1) DEFAULT NULL,
  `giornigaran` int(11) DEFAULT NULL,
  `riparingaran` bit(1) DEFAULT NULL,
  `attesaricambi` bit(1) DEFAULT NULL,
  `riparato` bit(1) NOT NULL DEFAULT b'0',
  `difetto` varchar(3072) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `bolle`
--

INSERT INTO `bolle` (`id`, `id_cliente`, `id_tecnico`, `tipo`, `marca`, `modello`, `accesincl`, `datain`, `dataout`, `note`, `costo`, `reltec`, `preventivo`, `giornigaran`, `riparingaran`, `attesaricambi`, `riparato`, `difetto`) VALUES
(7, 17, 6, 'Televisore', 'Samsung', 'slt62', 'Telecomando', '2017-07-04 08:52:46', NULL, 'urgenza riparazione', 150, 'problema di schermo', b'0', 0, b'1', b'0', b'1', 'problema schermo'),
(8, 18, 6, 'Stereo', 'Pioneer', 'z32', '', '2017-07-04 09:15:23', NULL, '', 55, '', b'1', 11, b'1', b'0', b'0', ''),
(9, 20, 6, 'Smartphone', 'Htc', 'h1', '', '2017-07-04 10:01:06', NULL, '', 100, '', b'0', NULL, b'0', b'0', b'0', ''),
(10, 17, 7, 'Cuffie', 'Bose', 'b6', '', '2017-07-05 08:00:42', NULL, '', 30, '', b'0', NULL, b'0', b'0', b'1', ''),
(11, 28, 7, 'Televisore', 'Toshiba', 't9', '', '2017-07-05 08:01:12', NULL, '', 300, '', b'0', NULL, b'0', b'0', b'1', ''),
(12, 18, 7, 'Auricolari', 'Bose', 'p90', '', '2017-07-05 08:16:44', NULL, '', 25, '', b'0', 11, b'0', b'0', b'0', ''),
(14, 17, 6, 'Auricolari', 'Sony', 's10', '', '2018-09-29 09:20:17', NULL, '', 20, '', b'0', NULL, b'0', b'0', b'0', ''),
(15, 20, 7, 'Smartphone', 'Huawei', 'p20', 'PellicolaSchermo', '2018-09-29 09:20:23', NULL, '', 320, '', b'0', NULL, b'0', b'0', b'0', ''),
(16, 20, 6, 'Stereo', 'Audiola', 'g1', '', '2018-09-29 09:50:11', NULL, '', 80, '', b'0', 0, b'0', b'0', b'0', ''),
(17, 17, 7, 'Stereo', 'Amstrad', 'a2', '', '2018-09-29 09:51:05', NULL, '', 50, '', b'0', 0, b'0', b'0', b'0', ''),
(18, 23, 6, 'Smartphone', 'Samsung', 's9', 'Fodero', '2018-12-03 19:53:52', NULL, 'surriscaldamento batteria e fotografie sgranate', 250, 'Batteria e fotocamera nuova', b'0', 12, b'0', b'0', b'0', 'problema fotocamera'),
(19, 23, 7, 'Smartphone', 'Samsung', 'S9', 'Fodero', '2018-12-14 10:57:00', NULL, 'Surriscaldamento batteria e problema fotocamera', 0, 'Batteria e fotocamera nuova', b'0', 0, b'0', b'0', b'0', 'Problema batteria e fotocamera');

-- --------------------------------------------------------

--
-- Struttura della tabella `clienti`
--

CREATE TABLE `clienti` (
  `id` int(8) UNSIGNED NOT NULL,
  `id_tecnico` int(8) DEFAULT NULL,
  `codfis` char(40) DEFAULT NULL,
  `pwd` varchar(256) NOT NULL DEFAULT '',
  `nome` char(50) DEFAULT NULL,
  `cognome` char(50) DEFAULT NULL,
  `indirizzo` char(100) DEFAULT NULL,
  `email` char(50) DEFAULT NULL,
  `tel` char(100) DEFAULT NULL,
  `note` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `clienti`
--

INSERT INTO `clienti` (`id`, `id_tecnico`, `codfis`, `pwd`, `nome`, `cognome`, `indirizzo`, `email`, `tel`, `note`) VALUES
(17, 6, 'MMMABA22W22W222B', 'Marcobliz.69', 'Marco', 'Borrelli', 'via de Sena', 'mard11@alice.it', '3662767929', ''),
(18, 6, 'GGAAAA22W22W222W', 'Blizgep.97', 'Giuseppe', 'Pezzillo', 'via Mameli', 'gpblitz@alice.it', '3554896321', ''),
(20, 7, 'SCLCRL79R11A509E', 'Carlo#67', 'Carlomaria', 'Sicondolfi', 'via Dei Caduti', 'Camndy@gmail.com', '3396578221', ''),
(23, 7, 'GRLCRL79R11A509W', 'Giuseppe.97', 'Giuseppe', 'Liorni', 'via Roma', '', '3332526890', ''),
(28, 6, 'BBBBBB22W22W222B', 'Bliz.111', 'Andrea', 'Basile', 'Via Mameli 33', 'aab@gmail.it', '3662767920', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotti`
--

CREATE TABLE `prodotti` (
  `id` int(10) UNSIGNED NOT NULL,
  `descrizione` varchar(3072) DEFAULT NULL,
  `nome_img` varchar(1024) DEFAULT NULL,
  `costo` double UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `prodotti`
--

INSERT INTO `prodotti` (`id`, `descrizione`, `nome_img`, `costo`) VALUES
(1, 'stereo pioneer', '', 49.95),
(2, 'pc portatile Asus', 'nuovo1.jpg', 630.9),
(3, 'auricolari bluetooth', 'nuovo2.png', 9.99),
(4, 'smartphone huawei p8', 'huawei-p8.png', 270.5),
(5, 'tablet lenovo ', 'tablet_lenovo.jpg', 150.99),
(6, 'tv samsung ', 'tv_samsung.png', 550);

-- --------------------------------------------------------

--
-- Struttura della tabella `tecnici`
--

CREATE TABLE `tecnici` (
  `id` int(8) NOT NULL,
  `pwd` char(20) DEFAULT NULL,
  `nome` char(30) DEFAULT NULL,
  `cognome` char(30) DEFAULT NULL,
  `codfis` char(16) DEFAULT NULL,
  `indirizzo` char(40) DEFAULT NULL,
  `email` char(50) DEFAULT NULL,
  `tel` char(20) DEFAULT NULL,
  `note` char(250) DEFAULT NULL,
  `type` varchar(64) NOT NULL DEFAULT 'tecnico'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `tecnici`
--

INSERT INTO `tecnici` (`id`, `pwd`, `nome`, `cognome`, `codfis`, `indirizzo`, `email`, `tel`, `note`, `type`) VALUES
(1, 'admin', 'Giuseppe', 'Pezzillo', 'admin', 'via Nazzareno 28', 'gep97@hotmail.it', '3662767920', '', 'admin'),
(6, '1234.Bliz', 'Pasquale', 'Imola', 'TTTTTT45W22W222P', 'Via Roma 3', '', '3554897852', '', 'tecnico'),
(7, 'Sdados.97', 'Giuseppe', 'Napolitano', 'SSSSSS45D22W222R', 'Via Seggio 44', '', '3319356947', '', 'tecnico');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `bolle`
--
ALTER TABLE `bolle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indici per le tabelle `clienti`
--
ALTER TABLE `clienti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indici per le tabelle `prodotti`
--
ALTER TABLE `prodotti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `tecnici`
--
ALTER TABLE `tecnici`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `bolle`
--
ALTER TABLE `bolle`
  MODIFY `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT per la tabella `clienti`
--
ALTER TABLE `clienti`
  MODIFY `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT per la tabella `prodotti`
--
ALTER TABLE `prodotti`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT per la tabella `tecnici`
--
ALTER TABLE `tecnici`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
